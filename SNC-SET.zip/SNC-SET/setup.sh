#!/bin/bash
######## https://github.com/slackhq/nebula/releases/ ##########

# Step 1: Install Required Packages
sudo apt update -i
sudo apt install -y wget tar  openssh-clients

# Step 2: Create Directory for Configuration and Certificates
sudo mkdir -p /usr/local/bin/snc/

# Step 3: Download and Extract Nebula
# wget https://github.com/slackhq/nebula/releases/download/v1.9.3/nebula-linux-amd64.tar.gz
# tar -xzf nebula-linux-amd64.tar.gz

sudo cp -r  nebula /usr/local/bin/snc/
sudo cp -r  nebula-cert /usr/local/bin/snc/
sudo cp -r  snc /etc/

# Step 4: Generate Certificates
# sudo /usr/local/bin/snc/nebula-cert ca -name "My Nebula CA"
#sudo mv  ca.* /etc/snc/

sudo cd /etc/snc
sudo /usr/local/bin/snc/nebula-cert sign -name "host" -ip "192.0.2.6/8"
sleep 10

sudo mv host* /etc/snc

# Step 5:  Permitions
sudo chmod 600 /etc/snc/ca.key
sudo chmod 644 /etc/snc/ca.crt


# Step 6: start service
sudo cp -r snc.service  /etc/systemd/system/snc.service
sudo systemctl daemon-reload
sudo systemctl enable scn
sudo systemctl daemon-reload
sudo systemctl start scn


echo "<<<<< Secure Network Connection Established >>>>>"

# Step 7: Set Up SSH Key Authentication
# Run the following commands manually on your local machine to generate SSH keys and copy them to the remote host:
# ssh-keygen -t rsa -b 4096 -C "your_email@example.com"
# ssh-copy-id bfarooq@172.51.100.1

# Step 8: Ensure Correct Permissions on the Remote Host
# Run the following commands manually on the remote host:
# ssh bfarooq@172.51.100.1
# chmod 700 ~/.ssh
# chmod 600 ~/.ssh/authorized_keys

# Step 9: Configure SSH Server on the Remote Host
#sudo sed -i 's/#PubkeyAuthentication yes/PubkeyAuthentication yes/' /etc/ssh/sshd_config
#sudo sed -i 's/#AuthorizedKeysFile .ssh\/authorized_keys/AuthorizedKeysFile .ssh\/authorized_keys/' /etc/ssh/sshd_config
#sudo systemctl restart sshd

# Step 10: Verify Nebula and SSH Connection
#sudo systemctl status snc
# ssh bfarooq@172.51.100.1
echo "sudo /usr/local/bin/snc/nebula-cert sign -name "host" -ip "192.0.2.6/8""

